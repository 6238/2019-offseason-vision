#!/bin/sh
cp build/libs/java-multiCameraServer-all.jar runCamera /home/pi
